package TDOperation;

import java.security.*;
import java.security.spec.*;

public class MD5 {
	public static byte[] GetMD5old(String s,int bit){
		try {
		byte[] strTemp = s.getBytes();
		MessageDigest mdTemp = MessageDigest.getInstance("MD5");
		mdTemp.update(strTemp);
		byte[] md = mdTemp.digest();		
		if (bit==64)
		{
			byte[] b=new byte[8];
			for (int i = 0; i < 8; i++ )
			{
			b[i]=md[i*2+1];
			}
			return b;
		}
		else
		{
			byte[] b=md;
			return b;
		}		
	}
		catch (Exception e){
		return null;
		}
		}
	public static String GetMD5(String s){
		char hexDigits[] = {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
		'e', 'f'};
		try {
		byte[] strTemp = s.getBytes();
		MessageDigest mdTemp = MessageDigest.getInstance("MD5");
		mdTemp.update(strTemp);
		byte[] md = mdTemp.digest();
		int j = md.length;
		char str[] = new char[j * 2];
		int k = 0;
		for (int i = 0; i < j; i++ ) {
		byte byte0 = md[i];
		str[k++ ] = hexDigits[byte0 >>> 4 & 0xf];
		str[k++ ] = hexDigits[byte0 & 0xf];
		}
		return new String(str);
		}
		catch (Exception e){
		return null;
		}
		}
	public static String GetMD5_64(String s){
		char hexDigits[] = {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
		'e', 'f'};
		try {
		byte[] strTemp = s.getBytes();
		MessageDigest mdTemp = MessageDigest.getInstance("MD5");
		mdTemp.update(strTemp);
		byte[] md = mdTemp.digest();
		int j = md.length;
		char str[] = new char[j * 2];
		int k = 0;
		for (int i = 0; i < j; i++ ) {
		byte byte0 = md[i];
		str[k++ ] = hexDigits[byte0 >>> 4 & 0xf];
		//str[k++ ] = hexDigits[byte0 & 0xf];
		}
		return new String(str);
		}
		catch (Exception e){
		return null;
		}
		}
	//only for test
		public static void main(String[] args){
			System.out.println(MD5.GetMD5("2db00000000002db00000000002111"));
			System.out.println(MD5.GetMD5_64("1db"));
 
		}

}

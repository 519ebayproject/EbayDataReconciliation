package GenerationHadoop;

import java.io.*;
import java.util.ArrayList;

import TDOperation.MD5;
/*
 * Author:wang xin
 * generate two MD5 files
 */
public class GenerateMD5 {

	public static void main(String[] args) throws IOException {
		
		if (args.length < 6 ) {
			System.out.println("Argument error");
			System.out.println("java -jar gendata.jar column.txt lineCount repeatCount wrongPrimaryKey outFile1 outFile2 ");
			return ;
		}
		Integer CountSize=1000;//�����С
		String colFile = args[0].trim();//��ȡ����Ϣ���ļ�
		long lineCount = Integer.valueOf(args[1].trim());//������
		Float rawRepCnt = Float.valueOf(args[2].trim());//PK��ͬ���ݲ�ͬ�İٷֱ�
		Float wrongPK =Float.valueOf(args[3].trim());//PK��ͬ�İٷֱ�
		String  outFile = args[4].trim();//����ļ�1,��׼�ļ�
		String  outFile2 = args[5].trim();//����ļ�2������������ļ�
		
		//�ж��ж����ļ��Ƿ����
		File  colF = new File(colFile);
		if (colF.exists() == false)  {
			System.out.println("Error column defintion file does't exist");
			return ;
		}
		
		//��ȡ�ļ�����
		ArrayList<String> cols = new ArrayList<String>();
		BufferedReader reader = new BufferedReader(new FileReader(colF));
		String line = "";
		while ((line = reader.readLine()) != null ) {
			System.out.println(line);
			cols.add(line.trim());//��ȡcol.txt�ļ��е���Ϣ
		}
		reader.close();
		BufferedWriter writer = new BufferedWriter(new FileWriter(outFile));//��һ������ļ�
		BufferedWriter writer2 = new BufferedWriter(new FileWriter(outFile2));///�ڶ�������ļ�
		StringBuilder StrBui = new StringBuilder();
		long i=0;
		//д�ļ�1
		for (i=1; i<=lineCount; i++) {	
			String LineNo = MyIntToStr(i*2);
			writer.write(i*2+",");	
			StrBui.delete(0, StrBui.length());
			StrBui.append(i*2);
			for (int j=0; j<cols.size(); j++) {			
				if (cols.get(j).equals("string") ) { //�ж�������string����int����
					StrBui.append("db");
					StrBui.append(LineNo);//�����string���ͣ�����db+�к�
				} else {
					StrBui.append(String.valueOf(i));//�����int���;���������
				}				
			}	
			//System.out.println(StrBui.toString());
			writer.write((MD5.GetMD5(StrBui.toString())).toString());//���ܺ�д���ļ�
			writer.write("\r\n");//����
		}
						
		//д�ļ�2
		long k=0;
		float partCorrect=CountSize*(1-rawRepCnt-wrongPK);//��ȷ����
		for(k=0; k<lineCount/CountSize;k++)
		{
			for (i=0;i<partCorrect;i++)
			{		
				String LineNo2 = MyIntToStr((k*CountSize+i+1)*2);//ֻȡż����
				writer2.write((k*CountSize+i+1)*2+",");	
				StrBui.delete(0, StrBui.length());
				StrBui.append((k*CountSize+i+1)*2);
				for (int j=0; j<cols.size(); j++) {
					if (cols.get(j).equals("string")) { //���Ϊstring
						StrBui.append("db");
						StrBui.append(LineNo2);
					} else { //���Ϊ int
						StrBui.append(String.valueOf(k*CountSize+i+1));					
				}					
			}
				writer2.write((MD5.GetMD5(StrBui.toString())).toString());
				writer2.write("\r\n");
			}
			for(;i<CountSize*(1-wrongPK);i++)//PKֵ��ȷ�����ݴ��󲿷�
			{
			//	String LineNo2 = MyIntToStr((k*CountSize+i+1)*2);
				writer2.write((k*CountSize+i+1)*2+",");	
				StrBui.delete(0, StrBui.length());
				StrBui.append((k*CountSize+i+1)*2);
				for (int j=0; j<cols.size(); j++) {
					if (cols.get(j).equals("string")) { //���Ϊstring
						StrBui.append("db");
						StrBui.append("$Error");//��Errorȡ������
					} else { //���Ϊ int
						StrBui.append(String.valueOf(k*CountSize+i));		//�������׼��1������			
				}
					
			}							
				writer2.write((MD5.GetMD5(StrBui.toString())).toString());
				writer2.write("\r\n");
			}
			for(;i<CountSize;i++) //PK��һ�µ����
			{
				String LineNo2 = MyIntToStr((k*CountSize+i+1)*2+1);
				writer2.write(((k*CountSize+i+1)*2+1)+",");	
				StrBui.delete(0, StrBui.length());
				StrBui.append((k*CountSize+i+1)*2+1);
				for (int j=0; j<cols.size(); j++) {
					if (cols.get(j).equals("string")) { //���Ϊstring
						StrBui.append("db");
						StrBui.append(LineNo2);
					} else { //���Ϊ int
						StrBui.append(String.valueOf(k*CountSize+i));					
				}
					
			}	
				writer2.write((MD5.GetMD5(StrBui.toString())).toString());
				writer2.write("\r\n");
			}
		}
		
		//�������µ�����
		int left=(int)(lineCount%CountSize);
		int y=0;
		for(y=0;y<left*(1-rawRepCnt-wrongPK);y++)//��ȷ������
		{
			String LineNo2 = MyIntToStr((k*CountSize+y+1)*2);
			writer2.write((k*CountSize+y+1)*2+",");	
			StrBui.delete(0, StrBui.length());
			StrBui.append((k*CountSize+y+1)*2);
			for (int j=0; j<cols.size(); j++) {
				if (cols.get(j).equals("string")) { //���Ϊstring
					StrBui.append("db");
					StrBui.append(LineNo2);
				} else { //���Ϊ int
					StrBui.append(String.valueOf(k*CountSize+y+1));					
			}
				
		}	
			writer2.write((MD5.GetMD5(StrBui.toString())).toString());
			writer2.write("\r\n");
		}
		for(;y<left*(1-wrongPK);y++)//PKֵ��ͬ�����ݲ�һ�������
		{
			//String LineNo2 = MyIntToStr((k*CountSize+y+1)*2);
			writer2.write((k*CountSize+y+1)*2+",");	
			StrBui.delete(0, StrBui.length());
			StrBui.append((k*CountSize+y+1)*2);
			for (int j=0; j<cols.size(); j++) {
				if (cols.get(j).equals("string")) { //���Ϊstring
					StrBui.append("db");
					StrBui.append("$Error");
				} else { //���Ϊ int
					StrBui.append(String.valueOf(k*CountSize+y));					
			}
				
		}	
			writer2.write((MD5.GetMD5(StrBui.toString())).toString());
			writer2.write("\r\n");
		}
		for(;y<left;y++) //PKֵ��һ��������Ҳ��һ�������
		{
			String LineNo2 = MyIntToStr((k*CountSize+y+1)*2+1);
			writer2.write(((k*CountSize+y+1)*2+1)+",");	
			StrBui.delete(0, StrBui.length());
			StrBui.append((k*CountSize+y+1)*2+1);
			for (int j=0; j<cols.size(); j++) {
				if (cols.get(j).equals("string")) { //���Ϊstring
					StrBui.append("db");
					StrBui.append(LineNo2);
				} else { //���Ϊ int
					StrBui.append(String.valueOf(k*CountSize+y));					
			}
				
		}		
			writer2.write((MD5.GetMD5(StrBui.toString())).toString());
			writer2.write("\r\n");
		}
		writer.close();
		writer2.close();
		System.out.println("Data Generated");

	}	
	private static String MyIntToStr(long i) {
		return MyIntToStr(i, 11);	//����ǰ0�ĸ���
	}
	private static String MyIntToStr(long i, int padlen) {
		StringBuilder StrBui = new StringBuilder(String.valueOf(i));
		
		while (StrBui.length() < padlen) {
			StrBui.insert(0,  '0');
		}
		return StrBui.toString();
	}
}
